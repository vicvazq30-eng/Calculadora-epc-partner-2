# HQS Calculadora Partner — Diferencial 70%

Calculadora interna de HQS Energy para calcular:

- Tamaño del sistema
- Watts
- Costo base del sistema
- EPC base
- EPC de venta
- Diferencia en comisión basada en 70%

## Desarrollo

```bash
npm install
npm run dev
```

## Producción

```bash
npm run build
npm start
```
